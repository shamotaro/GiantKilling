﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fileTextRplace
{
    class Program
    {

        // 設定ファイル読み込み
        public static string inFldPath = Properties.Settings.Default.inFldPath;
        public static string extension = Properties.Settings.Default.extension;
        public static string orgStr = Properties.Settings.Default.orgStr;
        public static string repStr = Properties.Settings.Default.repStr;

        // 定数
        public static UTF8Encoding ENC_UTF = new UTF8Encoding(true);

        static void Main(string[] args)
        {

            List<string> fl = new List<string>();

            // inFldPathフォルダ配下(サブフォルダ含まない)の拡張子がextensionであるファイルをすべて取得
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(@inFldPath);
            System.IO.FileInfo[] files =di.GetFiles(extension, System.IO.SearchOption.TopDirectoryOnly);

            foreach (System.IO.FileInfo f in files)
            {
                fl.Add(f.FullName);
            }

            for (int i= 0; i < fl.Count; i++)
            {
                // ファイルをENC_UTFコードとして開く
                System.IO.StreamReader sr = new System.IO.StreamReader(fl[i], ENC_UTF);
                //内容をすべて読み込む
                string s = sr.ReadToEnd();

                sr.Close();

                s = s.Replace(orgStr, repStr);

                // ファイルにENC_UTFコードで書き込む(上書き)
                StreamWriter sw = new StreamWriter(fl[i], false, ENC_UTF);

                sw.Write(s);
                sw.Close();
            }
        }
    }
}
